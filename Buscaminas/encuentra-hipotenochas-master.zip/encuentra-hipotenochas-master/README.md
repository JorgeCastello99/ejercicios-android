# encuentra-hipotenochas
A simple minesweeper-like game using Estenmáticas project's mascot.

http://nueva.estenmaticas.es/
